<?php
return
    array (
        'default' =>
            array (
                'servers' =>//配置集群，如果没有集群的话 设置单个server就可以了
                    array (
                            array (
                                'host' => '127.0.0.1',
                                'port' => 5672,
                                'login' => 'guest',
                                'password' => 'guest',
                                'vhost' => '/',
                            ),
                    ),
                'exchannels' =>
                    array (
                        'mailServers' =>//交换机
                            array (
                                'type' => 'direct',//交换机类型
                                'durable' => true,
                                'passive' => false,
                                'autoDelete' => true,
                                'internal' => false,
                                'noWait' => false,
                                'queues' =>//包含的队列
                                    array (
                                        'mail' =>
                                            array (
                                                'durable' => true,
                                                'passive' => false,
                                                'autoDelete' => false,
                                                'internal' => false,
                                                'noWait' => false,
                                                'routingKey' => 'siginMail',
                                            ),
                                    ),
                            ),
                    ),
            ),
    );