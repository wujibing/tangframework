<?php
return array (
        'default' =>
            array (
                'charset' => 'utf8',//编码
                'collate' => '',//字符集
                'dbName' => 'ss',//数据库
                'tablePrefix' => 'ss_',//表前缀
                'driver' => 'mysql',//驱动 暂时支持mysql pgsql
                'class' => '', //自定义的驱动类
                'persistent' => 1,//是否持久链接
                'readWriteSeparate' =>//是否读写分离
                    array (
                        'support' => false,//是否支持读写分离
                        'masterNumber' => 2,//写入服务器数量
                    ),
                'info' => //服务器数组信息
                    array (
                            array (
                                'host' => '127.0.0.1',//数据库地址
                                'username' => 'root',
                                'password' => 'wujibing',
                                'port' => '3306',
                                'unixSocket' => '',//使用unix socket链接 填写此项后会优先使用unix socket
                            )
                    ),
            ),
    );