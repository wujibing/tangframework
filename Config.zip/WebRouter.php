<?php
return
    array (
        'moduleName' => 'module',//模块变量名称
        'controllerName' => 'controller', //控制器变量名称
        'actionName' => 'action', //方法变量名称
        'defaultModule' => 'Index', //默认的模块
        'defaultController' => 'Index',//默认的控制器
        'defaultAction' => 'main',//默认的方法
        'model' => 2,//0 (普通模式); 1 (PATHINFO 模式); 2 (隐藏PHP模式); 3 (兼容模式)  默认为PATHINFO 模式////
        'delimiter' => '/',//控制器分割符
        'parametersDelimiter' => '_',//参数分割符
        'suffixs' => 'html|json|xml|yaml|htm|shtml|dwz|png',//允许的后缀名 当有该选项的时候，所有不包含此后缀的都会抛出404
        'defaultSuffix' => 'html',//默认的后缀名
        'paramsBindType' => 0,// URL变量绑定的类型 0 按变量名绑定 1 按变量顺序绑
        'pathInfo' => array (
                'parmName' => 's',//path info参数名
                'otherPathInfo' => array ('ORIG_PATH_INFO', 'REDIRECT_PATH_INFO', 'REDIRECT_URL'),//判断别名////
        ),
        'moduleAlias' => array (
                'A' => 'Admin',//AdminPath作为Admin模块的别名 这里要严格区分大小写
        ),
        'subDomain' => array (
                'support' => true,//是否开启子域名
                'rules' => array (
                ),
                'suffix' => '.com',//域名后缀 开启子域名必须填写
        ),
        'rewrite' =>
            array (
                'support' => 1,
                'rules' =>
                    array (
                        'public' =>
                            array (
                                'user/index/tg' =>
                                    array (
                                        'regex' => '/tg/([0-9]+)',
                                        'parameters' =>
                                            array (
                                                0 => 'userId',
                                            ),
                                    ),
                                'user/index/([a-zA-Z0-9]+)' =>
                                    array (
                                        'regex' => '/([a-zA-Z0-9]+)',
                                        'parameters' =>
                                            array (
                                                0 => 'action',
                                            ),
                                    ),
                                'index/([a-zA-Z0-9]+)/index' =>
                                    array (
                                        'regex' => '/rpc/([a-zA-Z0-9]+)',
                                        'parameters' =>
                                            array (
                                                0 => 'controller',
                                            ),
                                    ),
                                'user/([a-zA-Z0-9]+)/([a-zA-Z0-9]+)' =>
                                    array (
                                        'regex' => '/([a-zA-Z0-9]+)/([a-zA-Z0-9]+)',
                                        'parameters' =>
                                            array (
                                                0 => 'controller',
                                                1 => 'action',
                                            ),
                                    ),
                            ),
                    ),
            ),
    );