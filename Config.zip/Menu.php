<?php
return
    array (
        '系统管理' =>
            array (
                'list' =>
                    array (
                        0 =>
                            array (
                                'name' => '管理员',
                                'nurl' => 'admin/admin/main',
                            ),
                        1 =>
                            array (
                                'name' => '用户管理',
                                'nurl' => 'admin/user/main',
                            ),
                        2 =>
                            array (
                                'name' => '财务记录',
                                'nurl' => 'admin/caiwu/main',
                            ),
                        3 =>
                            array (
                                'name' => '节点管理',
                                'nurl' => 'admin/nodes/main',
                            ),
                        4 =>
                            array (
                                'name' => '服务器管理',
                                'nurl' => 'admin/servers/main',
                            ),
                        5 =>
                            array (
                                'name' => '充值管理',
                                'nurl' => 'admin/pays/main',
                            ),
                    ),
            ),
        '产品' =>
            array (
                'list' =>
                    array (
                        0 =>
                            array (
                                'name' => '产品列表',
                                'nurl' => 'admin/plans/main',
                            ),
                        1 =>
                            array (
                                'name' => '订单记录',
                                'nurl' => 'admin/ports/main',
                            ),
                    ),
            ),
    );