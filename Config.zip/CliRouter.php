<?php
return [
    'moduleName' => 'm',//模块变量名称
    'controllerName' => 'c', //控制器变量名称
    'actionName' => 'a', //方法变量名称
    'defaultModule' => 'Index', //默认的模块
    'defaultController' => 'Index',//默认的控制器
    'defaultAction' => 'main',//默认的方法
];