<?php
return [
    'debug' => true,//是否开启调试模式 不在调试模式下将屏蔽错误，缓存模板
    'timezone' => 'Asia/Chongqing', //时区设置
    'lang' => 'Zh-cn',//默认的语言
    'charset' => 'UTF-8',//编码
    'dataDirctory' => 'Data',//缓存 等数据目录
    '404Page' => '404.html',//404页面 开发者自定义404可放置在网站目录Lib/Pages里面
    'messagePage' => 'Message.html',//消息提示页面 开发者自定义消息提示页面可放置在网站目录Lib/Pages里面
    'exceptionPage' => 'Exception.html',//异常提示页面 开发者自定义异常提示可放置在网站目录Lib/Pages里面
    'services' => //开发者自定义服务或修改系统服务关联的类
    [
        'template' => '\Lib\Extend\TemplateManager',
    ],
    //token
    'token' =>
    [
        'cryptDriver' => '',
        'expire' => '86400',
    ],
    //ajax配置
    'ajax' =>
    [
        'requestName' => 'ajaxType', //get 参数名
        'callback' => 'callback'//给JS回调函数名
    ],
    //cookie配置
    'cookie' =>
    [
        'expire' => 86400, //时效
        'path' => '', //path
        'domain' => '',//域
        'prefix' => 'tang-'//cookie前缀
    ],
    //cache配置
    'cache' =>
    [
        'directory' => 'cache',//文件缓存的目录 位于data目录下
        'defaultDriver' => 'json',//默认的驱动  支持 database json redis memcached igbinary serialization apc 默认为json
        'database' =>[
            'source' => 'test',//使用数据库缓存所使用的数据源
            'tableName' => '',//数据库缓存表名 默认为cache
        ],
        'redisSource' => '',//使用redis的数据源名称 默认为cache
        "memcachedSource" => ''//使用memcached的数据源名称 默认为cache
    ],
    //session配置
    'session' =>
    [
        'defaultDriver' => 'database',//支持file database redis  memcached 默认使用json
        'directory' => 'session',//使用文件类session的目录
        'expire' =>86400,//有效期
        'database' => [
            'source' => '',//使用数据库session所使用的数据源
            'tableName' => 'session'//表名
        ],
        'redisSource' => 'session',//使用redis的数据源名称 默认为session
        "memcachedSource" => 'session'//使用memcached的数据源名称 默认为session
    ],
    //日志配置
    'log' =>[
        'record' => true,//是否开启日志
        //'recordLevel' => ['ALERT','SQL'],
        'recordLevel' => [],//允许记录的日志级别 可用值MERG ALERT CRIT ERR WARNING NOTIC INFO DEBUG SQL   为空的时候记录所有的级别
        'defaultDriver' => 'file',//支持file database redis  memcached
        'file' => [
            'directory' => 'log',//记录日志的文件夹,
            'filePath'=>'%Y-%m/TangLog-%y-%m-%d.log'//日志文件名格式  %后面加上date的日期格式就好了
        ],
        'database' =>
        [
            'source' => '',//使用的数据源
            'tableName' => 'log'//表名
        ]
    ],
    //表单格式化代码配置
    'form' =>[
        'admin' => '<tr><td ><label class="control-label x100">%s：</label>%s</td><td>%s</td></tr>'//amdin模块的表单格式化代码
    ],
    //ip定位配置
    'ipLocation' =>[
        'defaultDriver' => 'QQWry',//支持的驱动为 taobao sina QQWry 默认使用QQWry
        'QQWryDataPath' => '/data/dat/qqwry.dat'//qqwry的数据库位置
    ],
    //加密配置
    'crypt'=> [
        'defaultDriver' => 'aes', //aes为默认的驱动  支持aes blowFish loki97 thirdDes(3des) twoFish xTea gost加密方式
        'key' => '123wcef', //密钥
        'iv' => 'dsdss' //向量
    ]
];