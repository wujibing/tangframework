<?php
return [
    'directory' => 'Template',//模板目录 位于网站目录Lib下
    'defaultTheme' => 'Default',//默认主题
    'getThemeName' => 'theme',//get所使用的主题参数
    'defaultDriver' => 'html', //默认的模板引擎 html json xml yaml
    'cookieThemeName' => 'theme' //cookie所使用的主题参数
];