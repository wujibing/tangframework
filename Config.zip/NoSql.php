<?php
return array (
        'redis' =>
            array (
                'isMasterSlave' => true,//是否支持主从
                'isPconnect' => true,//是否持久链接
                'timeout' => '0.0',//超时
                'prefix' => '',//前缀
                'serialize' => '2',//序列方式 0不序列化 1PHP序列化函数 2 igbinary序列化函数 默认为2,
                'password' => '',
                'servers' => //服务器信息
                    array (
                        'cache' => //数据源名称对应的服务器
                            array (
                                    array (
                                        'host' => '121.199.60.141',
                                        'password' => '',//如果为空 将使用默认的密码
                                    ),
                            ),
                    ),
            ),
        'memcached' =>
            array (
                'servers' =>
                    array (
                        'default' =>
                            array (
                                    array (
                                        'host' => '192.168.31.8',
                                        'port' => '11211',
                                        'weight' => 0,
                                    ),
                                    array (
                                        'host' => '192.168.31.8',
                                    ),
                            ),
                        'session' =>
                            array (
                                    array (
                                        'host' => '192.168.31.8',
                                        'port' => 11212,
                                    ),
                            ),
                    ),
            ),
    );