<?php
return array (
        'defaultDriver' => 'local',//默认的存储引擎 支持qiniu upYun sFtp ftp
        'qiniu' =>//七牛的配置
            array (
                'buckets' =>
                    array (
                        'wodexx' =>
                            array (
                                'domain' => 'wodexx.qiniudn.com',
                                'isPrivate' => false,
                                //也可在这里设置单独的accessKey和secretKey
                            ),
                    ),
                //七牛通用的accessKey和secretKey 如果空间没有设置accessKey和secretKey将使用此项
                'accessKey' => 'hy90KF_2Whk6v10APvnSAoz-Nt7KzqObPFUCbPpq',
                'secretKey' => '3thEDg-YcR5HrXkNFxr8RkP8FI3RW88jruw8CS2e',
            ),
        'upYun' =>//又拍云
            array (
                'buckets' =>
                    array (
                        'testframework' =>
                            array (
                                'domain' => 'testframework.b0.upaiyun.com',
                                //也可在这里设置单独的user和password
                            ),
                    ),
                //又拍云通用的user和password 如果空间没有设置auser和password将使用此项
                'user' => 'wujibing',
                'password' => 'wujibing',
            ),
        'sFtp' =>//sftp
            array (
                'buckets' =>
                    array (
                        'image' =>
                            array (
                                'domain' => '192.168.31.8',
                                'user' => 'root',
                                'port' => 22,
                                'password' => 'wujibing',
                                'directory' => '/data/files/images',//根目录
                                'path' => '/images/',//存放文件夹
                            ),
                        'file' =>
                            array (
                                'domain' => '192.168.31.8',
                                'user' => 'root',
                                'port' => 22,
                                'password' => 'wujibing',
                                'directory' => '/data/files/zips',
                                'path' => '/zips/',
                            ),
                    ),
            ),
        'ftp' =>//ftp
            array (
                'buckets' =>
                    array (
                        'image' =>
                            array (
                                'domain' => '192.168.31.8',
                                'user' => 'ftp1',
                                'port' => 21,
                                'password' => 'abc',
                                'directory' => '/images/',//根目录
                                'path' => '/images/',//存放文件夹
                            ),
                        'file' =>
                            array (
                                'domain' => '192.168.31.8',
                                'user' => 'root',
                                'port' => 21,
                                'password' => 'wujibing',
                                'directory' => '/file/',
                                'path' => '/file/',
                            ),
                    ),
            ),
        'local' =>//使用本地文件夹
            array (
                'buckets' =>
                    array (
                        'image' =>
                            array (
                                'directory' => '/images/',//位于根目录的存放文件夹
                            ),
                    ),
            ),
    );